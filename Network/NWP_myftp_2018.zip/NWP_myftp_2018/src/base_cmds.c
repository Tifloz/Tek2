/*
** EPITECH PROJECT, 2022
** NWP_myftp_2018
** File description:
** Created by Florian Louvet,
*/
#include <zconf.h>
#include <libnet.h>
#include <ftp.h>

int	cmd_quit(int sock, client_t *login, char *buff)
{
    (void) buff;
    write(sock, "221 Goodbye.\r\n", 15);
    login->login = 0;
    if (login->user != NULL)
        free(login->user);
    if (login->pass != NULL)
        free(login->pass);
    free(login->p_dir);
    free(login->ip_serv);
    return (0);
}
